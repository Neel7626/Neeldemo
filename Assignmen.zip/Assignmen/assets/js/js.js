var owl = $('#client-logo');
owl.owlCarousel({
    items:6,
    loop:true,
    margin:10,
    autoplay:true,
    speed: 900,
    responsive:{
        0:{
            items:2
        },
        600:{
            items:3
        },
        1000:{
            items:6
        }
    }
});